package com.example.laboratoire2marlondaugustin;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.util.Log;

public class MainActivity extends AppCompatActivity {
    EditText et_nom,et_courriel,et_password,et_confirmer;
    CheckBox chk_condition,chk_afficher,chk_afficherValider;
    Button btn_sauvegarder,btn_quitter;
    TextView tv_valide;
    ImageView imgUser;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ImageView imgUser=(ImageView) findViewById(R.id.imageView_user);
        imgUser.setImageResource(R.drawable.user);
        et_password=(EditText) findViewById(R.id.et_password);
        et_confirmer=(EditText) findViewById(R.id.et_confirmer);
        chk_afficherValider=(CheckBox) findViewById(R.id.chk_confirmer);
        chk_afficher=(CheckBox) findViewById(R.id.chk_motDePasse);

    }
    public void onClickChk_Afficher(View view) {
        /*
            Lien pour voir les méthodes pour afficher et masquer
            un mot de passe.
            https://www.tutorialkart.com/kotlin-android/android-show-hide-password-in-edittext/
         */
        if (chk_afficher.isChecked()) {
            et_password.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
        } else {
            et_password.setTransformationMethod(PasswordTransformationMethod.getInstance());
        }
    }
    public void onClickChk_AfficherValider(View view) {
        if (chk_afficherValider.isChecked()) {
            et_confirmer.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
        } else {
            et_confirmer.setTransformationMethod(PasswordTransformationMethod.getInstance());
        }
    }
    public void onClickBtn_Sauvegarder(View view){
        Context contexte=getApplicationContext();
        int duree= Toast.LENGTH_LONG;
        String texte=getResources().getText(R.string.profil).toString();
        Toast msg_Toast= Toast.makeText(contexte,texte,duree);
        msg_Toast.setGravity(Gravity.TOP|Gravity.CENTER,0,0);
        msg_Toast.show();
    }
    public void onClickBtn_Quitter(View view){
        AlertDialog.Builder alerteDialogueBuilder=new AlertDialog.Builder(this);
        alerteDialogueBuilder.setMessage("Êtes-vous sûr de vouloir quitter l'application?");

        alerteDialogueBuilder.setPositiveButton("Oui", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                finish();
            }
        });
        alerteDialogueBuilder.setNegativeButton("Non", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {}
        });
        AlertDialog alerteDialog=alerteDialogueBuilder.create();
        alerteDialog.show();
    }
    @Override
    protected void onStart() {
        super.onStart();
        Log.d("Méthode onstart","L’activité est passée par la méthode onStart");
    }
    @Override
    protected void onResume() {
        super.onResume();
        Log.d("Méthode onResume","L’activité est passée par la méthode onResume");
    }
    @Override
    protected void onPause() {
        super.onPause();
        Log.d("Méthode onPause","L’activité est passée par la méthode onPause");
    }
    @Override
    protected void onStop() {
        super.onStop();
        Log.d("Méthode","L’activité est passée par la méthode onStop");
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d("Méthode","L’activité est passée par la méthode onDestroy");
    }
}